package org.dd4t.core.serializers.impl.xml;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.dd4t.contentmodel.exceptions.SerializationException;
import org.dd4t.core.serializers.impl.Serializer;
import com.fasterxml.jackson.xml.XmlMapper;

/**
 * anchorage
 *
 * @author R. Kempees
 * @since 16/10/14.
 */
public class XmlSerializer implements Serializer{

	private static final ObjectMapper mapper = XmlMapper()
	@Override public <T> T deserialize (final String content, final Class<T> aClass) throws SerializationException {
		return null;
	}

	@Override public String serialize (final Object item) throws SerializationException {
		return null;
	}
}
